import { useEffect, useRef, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import { Activity, ArrowDownLeft, ArrowLeftRight, ArrowUpRight, Banknote, Bell, BookOpen, CalendarClock, Calculator, ChartNoAxesCombined, ChevronLeft, Download, Eye, EyeOff, FileDown, HandCoins, Landmark, LockKeyhole, Moon, Pencil, Plus, Printer, ReceiptText, Settings, ShieldCheck, ShoppingBag, Sun, Trash2, Upload, Wallet, X } from 'lucide-react';

type Item = { id: string; kind: string; name?: string; amount?: number; date?: string; [key: string]: any };
type Prefs = { currency: string; decimals: number; dateFormat: string; theme: 'light' | 'dark'; hidden: boolean; pin: string };
const DB_NAME = 'hesabati-local-v1';
const today = () => new Date().toISOString().slice(0, 10);
const defaultPrefs: Prefs = { currency: 'YER', decimals: 2, dateFormat: 'ymd', theme: 'light', hidden: false, pin: '' };
const nav = [
  { key: 'home', text: 'الرئيسية', icon: Activity },
  { key: 'accounts', text: 'الحسابات', icon: Landmark },
  { key: 'transactions', text: 'الدخل والمصروف', icon: ArrowLeftRight },
  { key: 'debts', text: 'الديون', icon: HandCoins },
  { key: 'shops', text: 'حسابات المحلات', icon: ShoppingBag },
  { key: 'obligations', text: 'الالتزامات', icon: CalendarClock },
  { key: 'reports', text: 'التقارير', icon: ChartNoAxesCombined },
  { key: 'calculator', text: 'الآلة الحاسبة', icon: Calculator },
  { key: 'settings', text: 'الإعدادات', icon: Settings },
];
const titles: Record<string, string> = Object.fromEntries(nav.map(n => [n.key, n.text]));
const currencies = ['YER', 'SAR', 'USD', 'AED', 'EUR', 'EGP'];
const moneyIn = (v: string) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) throw new Error('أدخل مبلغاً صحيحاً أكبر من أو يساوي صفراً');
  const minor = Math.round(n * 100);
  if (!Number.isSafeInteger(minor)) throw new Error('المبلغ أكبر من الحد الآمن للتخزين');
  return minor;
};
const fmt = (minor = 0, currency = 'YER', decimals = 2) => new Intl.NumberFormat('ar-YE', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(minor / 100) + ' ' + currency;
const getDb = () => new Promise<IDBDatabase>((resolve, reject) => {
  const request = indexedDB.open(DB_NAME, 1);
  request.onupgradeneeded = () => request.result.createObjectStore('records', { keyPath: 'id' });
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => reject(request.error);
});
const allRecords = async (): Promise<Item[]> => {
  const db = await getDb();
  return new Promise((resolve, reject) => { const r = db.transaction('records').objectStore('records').getAll(); r.onsuccess = () => resolve(r.result as Item[]); r.onerror = () => reject(r.error); });
};
const saveRecord = async (record: Item) => {
  const db = await getDb();
  return new Promise<void>((resolve, reject) => { const r = db.transaction('records', 'readwrite').objectStore('records').put(record); r.onsuccess = () => resolve(); r.onerror = () => reject(r.error); });
};
const removeRecords = async (ids: string[]) => {
  const db = await getDb();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction('records', 'readwrite'); const store = tx.objectStore('records');
    ids.forEach(recordId => store.delete(recordId)); tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error);
  });
};
const replaceAll = async (items: Item[]) => {
  const db = await getDb();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction('records', 'readwrite'); const store = tx.objectStore('records'); store.clear();
    items.forEach(item => store.put(item)); tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error);
  });
};
const id = () => crypto.randomUUID();
function App() {
  const [records, setRecords] = useState<Item[]>([]);
  const [prefs, setPrefs] = useState<Prefs>(() => { try { return { ...defaultPrefs, ...JSON.parse(localStorage.getItem('hesabati-prefs') || '{}') }; } catch { return defaultPrefs; } });
  const [page, setPage] = useState('home');
  const [modal, setModal] = useState<{ kind: string; item?: Partial<Item> } | null>(null);
  const [modalForm, setModalForm] = useState<Record<string, any>>({});
  const [modalError, setModalError] = useState('');
  const [toast, setToast] = useState('');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [accountFilter, setAccountFilter] = useState('all');
  const [statementType, setStatementType] = useState('all');
  const [showArchivedAccounts, setShowArchivedAccounts] = useState(false);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [splash, setSplash] = useState(true);
  const [pinGate, setPinGate] = useState(false);
  const [pinEntry, setPinEntry] = useState('');
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [calc, setCalc] = useState('0');
  const [calcExpr, setCalcExpr] = useState('');
  const [calcFresh, setCalcFresh] = useState(true);
  const [busy, setBusy] = useState(false);
  const writeLock = useRef(false);
  const [reportPeriod, setReportPeriod] = useState('month');
  const [reportCurrency, setReportCurrency] = useState(prefs.currency);
  useEffect(() => {
    allRecords().then(setRecords).catch(() => showToast('تعذر فتح قاعدة البيانات المحلية'));
    const t = window.setTimeout(() => setSplash(false), 1700);
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/service-worker.js').catch(() => undefined);
    const listener = (e: Event) => { e.preventDefault(); setInstallPrompt(e); };
    window.addEventListener('beforeinstallprompt', listener);
    return () => { clearTimeout(t); window.removeEventListener('beforeinstallprompt', listener); };
  }, []);
  useEffect(() => { localStorage.setItem('hesabati-prefs', JSON.stringify(prefs)); document.documentElement.classList.toggle('dark', prefs.theme === 'dark'); }, [prefs]);
  useEffect(() => { if (prefs.pin) setPinGate(true); }, []);
  function showToast(text: string) { setToast(text); window.setTimeout(() => setToast(''), 2600); }
  const accounts = records.filter(r => r.kind === 'account' && !r.archived);
  const shops = records.filter(r => r.kind === 'shop' && !r.archived);
  const byId = (key?: string) => records.find(r => r.id === key);
  const accountBalance = (account: Item) => {
    return (account.opening || 0) + records.reduce((sum, r) => {
      if (r.accountId !== account.id) return sum;
      if (r.kind === 'transaction') return sum + (r.type === 'income' ? r.amount || 0 : r.type === 'expense' ? -(r.amount || 0) : 0);
      if (r.kind === 'transfer') return sum + (r.fromId === account.id ? -(r.amount || 0) : r.toId === account.id ? r.amount || 0 : 0);
      if (r.kind === 'debtPayment') return sum + (r.direction === 'owedToMe' ? r.amount || 0 : -(r.amount || 0));
      if (r.kind === 'shopPayment') return sum - (r.amount || 0);
      if (r.kind === 'shopCashPurchase') return sum - (r.amount || 0);
      if (r.kind === 'shopReturn') return sum + (r.amount || 0);
      return sum;
    }, 0);
  };
  const transactions = records.filter(r => ['transaction', 'transfer'].includes(r.kind)).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  const monthStart = today().slice(0, 7);
  const monthTransactions = records.filter(r => r.kind === 'transaction' && (r.date || '').startsWith(monthStart) && byId(r.accountId)?.currency === prefs.currency);
  const incomeMonth = monthTransactions.filter(r => r.type === 'income').reduce((s, r) => s + (r.amount || 0), 0);
  const expenseMonth = monthTransactions.filter(r => r.type === 'expense').reduce((s, r) => s + (r.amount || 0), 0);
  const totalBalance = accounts.filter(a => a.currency === prefs.currency).reduce((s, a) => s + accountBalance(a), 0);
  const debts = records.filter(r => r.kind === 'debt');
  const openObligations = records.filter(r => r.kind === 'obligation' && r.status !== 'paid');
  const recent = records.filter(r => ['transaction', 'transfer', 'debtPayment', 'shopCashPurchase', 'shopPayment'].includes(r.kind)).sort((a, b) => (b.date || '').localeCompare(a.date || '')).slice(0, 5);
  async function persist(next: Item) {
    if (writeLock.current) return;
    writeLock.current = true;
    setBusy(true);
    try {
      await saveRecord(next);
      setRecords(await allRecords());
      showToast('تم الحفظ على هذا الجهاز');
    } catch { showToast('تعذر حفظ السجل، حاول مرة أخرى'); }
    finally { writeLock.current = false; setBusy(false); }
  }
  async function deleteItem(item: Item) {
    const cascade = item.kind === 'debt' ? records.filter(r=>r.kind==='debtPayment'&&r.debtId===item.id) : item.kind === 'shop' ? records.filter(r=>r.shopId===item.id) : [];
    if (!window.confirm(`هل تريد حذف هذا السجل${cascade.length ? ` مع ${cascade.length} حركة مرتبطة` : ''}؟ سيُعاد احتساب الأرصدة من السجلات المتبقية.`)) return;
    await removeRecords([item.id,...cascade.map(r=>r.id)]); setRecords(await allRecords()); showToast('تم حذف السجل وإعادة احتساب الأثر');
  }
  async function archiveAccount(account: Item) {
    const archive = !account.archived;
    if (!window.confirm(archive ? 'أرشفة الحساب؟ سيبقى محفوظاً في السجل ولن يظهر ضمن الحسابات النشطة.' : 'إعادة الحساب إلى الحسابات النشطة؟')) return;
    await persist({ ...account, archived: archive, updatedAt: new Date().toISOString() });
  }
  function launch(kind: string, item?: Partial<Item>) {
    setModalForm({ date: today(), currency: item?.currency || prefs.currency, type: kind === 'transaction' ? 'expense' : undefined, direction: kind === 'debt' ? 'owedToMe' : item?.direction, recurrence: 'مرة واحدة', ...item, amount: item?.amount == null ? '' : String(item.amount / 100), opening: item?.opening == null ? '' : String(item.opening / 100) });
    setModalError('');
    setModal({ kind, item });
  }
  function changePage(key: string) { setPage(key); setSearch(''); setFilter('all'); }
  function updatePrefs(patch: Partial<Prefs>) { setPrefs(p => ({ ...p, ...patch })); }
  function exportBackup() {
    const blob = new Blob([JSON.stringify({ app: 'حساباتي', version: 1, exportedAt: new Date().toISOString(), records }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `hesabati-backup-${today()}.json`; a.click(); URL.revokeObjectURL(a.href); showToast('تم تنزيل نسخة احتياطية');
  }
  function importBackup(file?: File) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const data = JSON.parse(String(reader.result));
        if (!data || !Array.isArray(data.records) || data.records.some((r: any) => !r.id || !r.kind)) throw new Error();
        const replacement = window.confirm('استبدال: هل تريد حذف كل السجلات الحالية واستبدالها بهذه النسخة؟ اضغط إلغاء لاختيار الدمج.');
        const existing = await allRecords();
        const unique = new Map<string,Item>();
        for(const row of data.records as Item[]) {
          if(typeof row.id!=='string'||typeof row.kind!=='string'||!Number.isSafeInteger(row.amount??0)) throw new Error();
          if(!unique.has(row.id)) unique.set(row.id,{...row});
        }
        if(replacement) {
          if(!window.confirm(`تأكيد أخير: سيتم استبدال ${existing.length} سجلاً بـ ${unique.size} سجل. هذا الإجراء لا يمكن التراجع عنه.`)) return;
          await replaceAll([...unique.values()]);
          setRecords(await allRecords()); showToast(`تم استبدال البيانات بـ ${unique.size} سجل`);
        } else {
          if(!window.confirm('دمج: ستبقى السجلات الحالية، وستُضاف السجلات ذات المعرّفات الجديدة فقط. هل تتابع؟')) return;
          const seen = new Set(existing.map(r => r.id));
          const additions = [...unique.values()].filter(r => !seen.has(r.id));
          for (const row of additions) await saveRecord(row);
          setRecords(await allRecords()); showToast(`أضيف ${additions.length} سجل جديد`);
        }
      } catch { showToast('الملف غير صالح أو لا يحتوي نسخة حساباتي'); }
    };
    reader.readAsText(file);
  }
  function printPage() { window.print(); }
  function exportCsv(rows: Item[]) {
    const headers = ['التاريخ', 'النوع', 'الوصف', 'التصنيف', 'الحساب', 'المبلغ', 'الطرف'];
    const body = rows.map(r => [r.date || '', r.type || r.kind, r.description || r.name || '', r.category || '', byId(r.accountId)?.name || '', ((r.amount || 0) / 100).toFixed(2), r.counterparty || r.person || '']);
    const csv = '\ufeff' + [headers, ...body].map(row => row.map(v => `"${String(v).replaceAll('"', '""')}"`).join(',')).join('\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); a.download = `hesabati-report-${today()}.csv`; a.click(); URL.revokeObjectURL(a.href);
  }
  function calcKey(key: string) {
    if (key === 'C') { setCalc('0'); setCalcExpr(''); setCalcFresh(true); return; }
    if (key === '⌫') { setCalc(v => v.length > 1 ? v.slice(0, -1) : '0'); return; }
    if (key === '=') {
      try { const safe = calcExpr + calc; if (!/^[\d.+\-*/()% ]+$/.test(safe)) return; const result = Function(`"use strict";return (${safe.replaceAll('×', '*').replaceAll('÷', '/')})`)(); if (Number.isFinite(result)) { setCalc(String(Number(result.toFixed(8)))); setCalcExpr(''); setCalcFresh(true); } } catch { showToast('تعذر إتمام العملية'); } return;
    }
    if ('+-×÷%'.includes(key)) { setCalcExpr(calcExpr + calc + (key === '×' ? '*' : key === '÷' ? '/' : key)); setCalc('0'); setCalcFresh(true); return; }
    setCalc(v => calcFresh ? (key === '.' ? '0.' : key) : v === '0' && key !== '.' ? key : v + key); setCalcFresh(false);
  }
  const visibleNav = nav;
  function NavButtons() { return <>{visibleNav.map(n => { const Icon = n.icon; return <button data-testid={`nav-${n.key}`} key={n.key} className={`nav-button ${page === n.key ? 'active' : ''}`} onClick={() => changePage(n.key)}><Icon/><span>{n.text}</span></button>; })}</>; }
  function pageHeader(title: string, subtitle: string, action?: ReactNode) {
    return <div className="page-head"><div><h2>{title}</h2><p>{subtitle}</p></div>{action}</div>;
  }
  function money(amount: number, currency?: string) { return prefs.hidden ? '••••••' : fmt(amount, currency || prefs.currency, prefs.decimals); }
  function dateLabel(value?: string) {
    if(!value) return '—';
    const parts=new Intl.DateTimeFormat('ar-u-nu-arab',{day:'2-digit',month:'2-digit',year:'numeric'}).formatToParts(new Date(`${value.slice(0,10)}T12:00:00`));
    const part=(type:string)=>parts.find(p=>p.type===type)?.value||'';
    return prefs.dateFormat==='dmy' ? `${part('day')}/${part('month')}/${part('year')}` : `${part('year')}/${part('month')}/${part('day')}`;
  }
  function empty(title: string, text: string, button?: string, onClick?: () => void) {
    return <div className="empty-state"><div className="empty-illustration"><BookOpen size={22}/></div><strong>{title}</strong><p>{text}</p>{button && <button className="button small" onClick={onClick}><Plus size={15}/>{button}</button>}</div>;
  }
  function dashboard() {
    const dueSoon = openObligations.filter(o => o.dueDate && o.dueDate <= new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
    return <>
      <div className="summary-grid">
        <div className="summary-card primary-card"><div className="metric-label"><span className="metric-icon"><Wallet size={15}/></span> مجموع الأرصدة · {prefs.currency}</div><div className={`metric-value ${prefs.hidden ? 'hidden-balances' : ''}`}>{money(totalBalance)}</div><div className="metric-foot">ضمن الحسابات النشطة وبعملتك الافتراضية</div></div>
        <div className="summary-card"><div className="metric-label"><span className="metric-icon"><ArrowDownLeft size={15}/></span> دخل هذا الشهر</div><div className={`metric-value positive ${prefs.hidden ? 'hidden-balances' : ''}`}>{money(incomeMonth)}</div><div className="metric-foot">من سجلاتك الفعلية</div></div>
        <div className="summary-card"><div className="metric-label"><span className="metric-icon"><ArrowUpRight size={15}/></span> مصروف هذا الشهر</div><div className={`metric-value negative ${prefs.hidden ? 'hidden-balances' : ''}`}>{money(expenseMonth)}</div><div className="metric-foot">من سجلاتك الفعلية</div></div>
      </div>
      <div className="dashboard-grid">
        <div>
          <section className="panel"><div className="panel-head"><div><h3>آخر الحركات</h3><p>تظهر هنا المعاملات المسجلة على جهازك</p></div><button className="panel-link" onClick={() => changePage('transactions')}>عرض الكل <ChevronLeft size={14}/></button></div>
            {recent.length ? <div className="activity-list">{recent.map(r => <div className="activity-row" key={r.id}><div className="activity-mark">{r.type === 'income' ? <ArrowDownLeft size={17}/> : r.type === 'expense' ? <ArrowUpRight size={17}/> : <ArrowLeftRight size={17}/>}</div><div className="activity-copy"><b>{r.description || r.person || r.type || 'حركة مالية'}</b><small>{dateLabel(r.date)} · {byId(r.accountId)?.name || (r.kind === 'transfer' ? 'تحويل بين حسابات' : '')}</small></div><div className={`activity-amount ${r.type === 'income' ? 'positive' : 'negative'}`}>{r.kind === 'transfer' ? '' : r.type === 'income' ? '+' : '−'}{money(r.amount || 0,byId(r.accountId)?.currency)}</div></div>)}</div> : empty('مساحتك المالية جاهزة', 'ابدأ بإضافة حساب أو سجل حركة مالية، وستظهر ملخصاتك هنا دون أي بيانات تجريبية.', 'إضافة حركة', () => launch('transaction'))}
          </section>
          <section className="panel"><div className="panel-head"><div><h3>حساباتك</h3><p>{accounts.length} حساب نشط</p></div><button className="panel-link" onClick={() => changePage('accounts')}>إدارة الحسابات <ChevronLeft size={14}/></button></div>
            {accounts.length ? <div className="account-mini">{accounts.slice(0, 4).map(a => <div className="account-tile" key={a.id}><span>{a.name} · {a.currency}</span><b>{money(accountBalance(a), a.currency)}</b></div>)}</div> : empty('لا توجد حسابات بعد', 'أضف حساباً نقدياً أو بنكياً لتبدأ بتسجيل الأرصدة.', 'إضافة حساب', () => launch('account'))}
          </section>
        </div>
        <div>
          <section className="panel"><div className="panel-head"><div><h3>الالتزامات القادمة</h3><p>تذكير محلي دون خصم تلقائي</p></div><CalendarClock size={18}/></div>{dueSoon.length ? dueSoon.slice(0, 4).map(o => <div className="activity-row" key={o.id}><div className="activity-mark"><Bell size={16}/></div><div className="activity-copy"><b>{o.name}</b><small>موعد الاستحقاق {o.dueDate}</small></div><div className="activity-amount">{money(o.amount || 0)}</div></div>) : empty('لا توجد مواعيد قريبة', 'أضف الإيجار أو الفواتير أو الأقساط لتتذكرها في الوقت المناسب.', 'إضافة التزام', () => launch('obligation'))}</section>
          <section className="panel"><div className="panel-head"><div><h3>أرصدة المحلات</h3><p>الرصيد المتبقي للمتابعة</p></div><ShoppingBag size={18}/></div>{shops.length ? shops.slice(0, 4).map(s => <div className="activity-row" key={s.id}><div className="activity-mark"><ReceiptText size={16}/></div><div className="activity-copy"><b>{s.name}</b><small>{s.balanceDirection || 'حساب متجر'}</small></div><div className="activity-amount">{money(shopBalance(s), s.currency)}</div></div>) : empty('سجل حسابات المحلات', 'أضف مشترياتك الآجلة ومدفوعاتك لتعرف المتبقي لكل محل.', 'إضافة محل', () => launch('shop'))}</section>
        </div>
      </div>
    </>;
  }
  function shopBalance(shop: Partial<Item>) {
    return (shop.opening || 0) + records.reduce((s, r) => {
      if (r.shopId !== shop.id) return s;
      if (r.kind === 'shopCreditPurchase') return s + (r.amount || 0);
      if (r.kind === 'shopPayment' || r.kind === 'shopReturn') return s - (r.amount || 0);
      if (r.kind === 'shopAdjustment') return s + ((r.direction === 'increase' ? 1 : -1) * (r.amount || 0));
      return s;
    }, 0);
  }
  function columnsTable(rows: Item[], mode: string) {
    if (!rows.length) return empty('لا توجد سجلات مطابقة', 'عندما تسجل معلوماتك ستظهر هنا مع أدوات البحث والتصفية.', mode === 'accounts' ? 'إضافة حساب' : mode === 'shops' ? 'إضافة محل' : 'إضافة سجل', () => launch(mode === 'accounts' ? 'account' : mode === 'shops' ? 'shop' : mode === 'debts' ? 'debt' : mode === 'obligations' ? 'obligation' : 'transaction'));
    return <div className="table-wrap"><table className="data-table"><thead><tr>{(mode === 'accounts' ? ['الحساب', 'النوع', 'الرصيد الافتتاحي', 'الرصيد الحالي', 'العملة', 'إجراءات'] : mode === 'transactions' ? ['التاريخ', 'النوع', 'الوصف', 'التصنيف', 'الحساب', 'المبلغ', 'إجراءات'] : mode === 'debts' ? ['الشخص', 'الاتجاه', 'الأصل', 'المتبقي', 'التاريخ', 'إجراءات'] : mode === 'shops' ? ['المحل', 'جهة الاتصال', 'الرصيد المتبقي', 'العملة', 'إجراءات'] : mode === 'obligations' ? ['الالتزام', 'النوع', 'التكرار', 'الاستحقاق', 'المبلغ', 'الحالة', 'إجراءات'] : ['التاريخ', 'النوع', 'الوصف', 'المبلغ', 'إجراءات']).map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map(r => <tr key={r.id}>
      {mode === 'accounts' ? <><td><b>{r.name}</b>{r.archived&&<small style={{display:'block',color:'var(--muted-foreground)'}}>مؤرشف</small>}</td><td>{r.accountType || 'نقدي'}</td><td>{money(r.opening || 0, r.currency)}</td><td><b>{money(accountBalance(r), r.currency)}</b></td><td>{r.currency}</td><td><div className="row-actions"><button className="row-action" title="تعديل" onClick={() => launch('account', r)}><Pencil/></button><button className="row-action" title={r.archived?'استعادة':'أرشفة'} onClick={() => archiveAccount(r)}>{r.archived?<Upload/>:<Trash2/>}</button></div></td></>
      : mode === 'transactions' ? <><td>{dateLabel(r.date)}</td><td><span className={`badge ${r.type === 'income' ? 'good' : r.type === 'expense' ? 'warn' : ''}`}>{r.kind === 'transfer' ? 'تحويل' : r.type === 'income' ? 'دخل' : 'مصروف'}</span></td><td>{r.description || r.counterparty || '—'}</td><td>{r.category || '—'}</td><td>{r.kind === 'transfer' ? `${byId(r.fromId)?.name || ''} ← ${byId(r.toId)?.name || ''}` : byId(r.accountId)?.name || '—'}</td><td><b>{money(r.amount || 0, byId(r.accountId)?.currency)}</b></td><td><div className="row-actions"><button className="row-action" title="تعديل" onClick={() => launch(r.kind, r)}><Pencil/></button><button className="row-action" title="حذف" onClick={() => deleteItem(r)}><Trash2/></button></div></td></>
      : mode === 'debts' ? <><td><b>{r.person}</b><small style={{display:'block',color:'var(--muted-foreground)'}}>{r.note}</small></td><td>{r.direction === 'owedToMe' ? 'مستحق لي' : 'مستحق عليّ'}</td><td>{money(r.amount || 0, r.currency)}</td><td><b>{money((r.amount || 0) - records.filter(p => p.kind === 'debtPayment' && p.debtId === r.id).reduce((s,p)=>s+(p.amount||0),0),r.currency)}</b></td><td>{dateLabel(r.date)}</td><td><div className="row-actions"><button className="row-action" title="كشف حساب الشخص" onClick={() => {setFilter(r.id);setPage('debtStatement');}}><BookOpen/></button><button className="row-action" title="تسديد جزئي" onClick={() => launch('debtPayment', { debtId: r.id, direction: r.direction, currency: r.currency })}><Banknote/></button><button className="row-action" title="تعديل الدين" onClick={() => launch('debt', r)}><Pencil/></button><button className="row-action" title="حذف" onClick={() => deleteItem(r)}><Trash2/></button></div></td></>
      : mode === 'shops' ? <><td><b>{r.name}</b></td><td>{r.contact || r.phone || '—'}</td><td><b>{money(shopBalance(r), r.currency)}</b><small style={{display:'block',color:'var(--muted-foreground)'}}>{shopBalance(r) >= 0 ? 'مستحق للمحل' : 'رصيد دائن لي'}</small></td><td>{r.currency}</td><td><div className="row-actions"><button className="row-action" title="شراء آجل" onClick={() => launch('shopCreditPurchase', { shopId: r.id })}><Plus/></button><button className="row-action" title="دفعة" onClick={() => launch('shopPayment', { shopId: r.id })}><Banknote/></button><button className="row-action" title="كشف حساب" onClick={() => { setFilter(r.id); setPage('shopStatement'); }}><BookOpen/></button><button className="row-action" title="تعديل" onClick={() => launch('shop', r)}><Pencil/></button><button className="row-action" title="حذف" onClick={() => deleteItem(r)}><Trash2/></button></div></td></>
      : mode === 'obligations' ? <><td><b>{r.name}</b></td><td><span className={`badge ${r.nature==='income'?'good':'warn'}`}>{r.nature==='income'?'دخل متكرر':'التزام'}</span></td><td>{r.recurrence || 'مرة واحدة'}</td><td>{dateLabel(r.dueDate)}</td><td>{money(r.amount || 0,r.currency)}</td><td><button className={`badge ${r.status === 'paid' ? 'good' : r.dueDate < today() ? 'late' : 'warn'}`} onClick={() => persist({...r,status:r.status === 'paid' ? 'due' : 'paid'})}>{r.status === 'paid' ? 'مدفوع' : r.dueDate < today() ? 'متأخر' : 'مستحق'}</button></td><td><div className="row-actions"><button className="row-action" title="تعديل" onClick={() => launch('obligation',r)}><Pencil/></button><button className="row-action" title="حذف" onClick={() => deleteItem(r)}><Trash2/></button></div></td></>
      : <><td>{r.date}</td><td>{r.kind}</td><td>{r.description || r.person || r.name}</td><td>{money(r.amount || 0)}</td><td><div className="row-actions"><button className="row-action" title="تعديل" onClick={() => launch(r.kind,r)}><Pencil/></button><button className="row-action" title="حذف" onClick={() => deleteItem(r)}><Trash2/></button></div></td></>}
    </tr>)}</tbody></table></div>;
  }
  function debtStatement() {
    const debt = byId(filter);
    const payments = records.filter(r=>r.kind==='debtPayment'&&r.debtId===filter).sort((a,b)=>(a.date||'').localeCompare(b.date||''));
    const paid = payments.reduce((sum,r)=>sum+(r.amount||0),0);
    return <>
      {pageHeader(`كشف حساب · ${debt?.person || 'الشخص'}`, 'أصل الدين وكل دفعة مسجلة بترتيبها الزمني.', <div style={{display:'flex',gap:8}}><button className="button ghost" onClick={printPage}><Printer/>طباعة / PDF</button><button className="button" onClick={()=>launch('debtPayment',{debtId:filter,direction:debt?.direction,currency:debt?.currency})}><Plus/>تسجيل سداد</button></div>)}
      <div className="summary-grid"><div className="summary-card"><div className="metric-label">أصل الدين</div><div className="metric-value">{money(debt?.amount||0,debt?.currency)}</div></div><div className="summary-card"><div className="metric-label">إجمالي السداد</div><div className="metric-value positive">{money(paid,debt?.currency)}</div></div><div className="summary-card primary-card"><div className="metric-label">المتبقي · {debt?.direction==='owedToMe'?'مستحق لي':'مستحق عليّ'}</div><div className="metric-value">{money((debt?.amount||0)-paid,debt?.currency)}</div></div></div>
      <section className="panel"><div className="panel-head"><div><h3>كشف الدفعات</h3><p>{debt?.note || 'الرصيد لا يتغير إلا عند تسجيل دفعة فعلية.'}</p></div></div>
      {payments.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>التاريخ</th><th>البيان</th><th>الحساب النقدي</th><th>المبلغ</th><th>إجراءات</th></tr></thead><tbody><tr><td>{debt?.date}</td><td>أصل الدين · {debt?.direction==='owedToMe'?'مستحق لي':'مستحق عليّ'}</td><td>—</td><td>{money(debt?.amount||0,debt?.currency)}</td><td>—</td></tr>{payments.map(p=><tr key={p.id}><td>{p.date}</td><td>{p.description||'سداد'}</td><td>{byId(p.accountId)?.name||'—'}</td><td>{money(p.amount||0,debt?.currency)}</td><td><div className="row-actions"><button className="row-action" title="تعديل السداد" onClick={()=>launch('debtPayment',p)}><Pencil/></button><button className="row-action" title="حذف السداد" onClick={()=>deleteItem(p)}><Trash2/></button></div></td></tr>)}</tbody></table></div> : empty('لا توجد دفعات بعد','تسجيل الدين لا يحرك الرصيد النقدي. أضف دفعة عند استلامها أو دفعها فعلياً.','تسجيل سداد',()=>launch('debtPayment',{debtId:filter,direction:debt?.direction,currency:debt?.currency}))}
      </section>
    </>;
  }
  function listPage() {
    const kindMap: Record<string, string> = { accounts: 'account', transactions: 'transaction', debts: 'debt', shops: 'shop', obligations: 'obligation' };
    const mode = page;
    let rows = records.filter(r => r.kind === kindMap[mode] && (mode==='accounts' ? showArchivedAccounts || !r.archived : !r.archived));
    if (mode === 'transactions') rows = transactions;
    if (mode === 'debts') rows = debts;
    if (mode === 'obligations') rows = records.filter(r => r.kind === 'obligation');
    if (mode === 'shops') rows = shops;
    if (mode === 'transactions' && filter !== 'all') rows = rows.filter(r => r.type === filter);
    if (mode === 'transactions' && accountFilter !== 'all') rows = rows.filter(r => r.accountId === accountFilter || r.fromId === accountFilter || r.toId === accountFilter);
    if ((mode === 'transactions' || mode === 'shops' || mode === 'debts' || mode === 'obligations') && fromDate) rows = rows.filter(r => (r.date || r.dueDate || '') >= fromDate);
    if ((mode === 'transactions' || mode === 'shops' || mode === 'debts' || mode === 'obligations') && toDate) rows = rows.filter(r => (r.date || r.dueDate || '') <= toDate);
    if (mode === 'obligations' && filter !== 'all') rows = rows.filter(r => r.status === filter);
    if (search.trim()) rows = rows.filter(r => JSON.stringify(r).toLowerCase().includes(search.toLowerCase()));
    const actionText: Record<string,string> = { accounts:'حساب جديد', transactions:'إضافة حركة', debts:'تسجيل دين', shops:'إضافة محل', obligations:'إضافة التزام' };
    const actionKind: Record<string,string> = { accounts:'account', transactions:'transaction', debts:'debt', shops:'shop', obligations:'obligation' };
    return <>
      {pageHeader(titles[page], page === 'accounts' ? 'كل أرصدتك في مكان واحد، مع سجل واضح لكل حساب.' : page === 'transactions' ? 'سجّل الدخل والمصروف والتحويلات، ثم راجع أثرها على الحسابات.' : page === 'debts' ? 'تابع ما لك وما عليك مع سجل سداد جزئي أو كامل.' : page === 'shops' ? 'حسابات المشتريات والدفعات والفواتير لدى المحلات.' : 'تذكيرات محلية بالمواعيد دون أي خصم تلقائي.', <div style={{display:'flex',gap:8}}>{page==='accounts'&&<button className="button ghost" onClick={()=>setShowArchivedAccounts(v=>!v)}>{showArchivedAccounts?'الحسابات النشطة':'عرض المؤرشفة'}</button>}<button className="button" onClick={() => launch(actionKind[page])}><Plus/>{actionText[page]}</button></div>)}
      {page === 'transactions' && <div className="filters"><label className="filter-field"><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">كل الحركات</option><option value="income">الدخل</option><option value="expense">المصروف</option><option value="transfer">التحويلات</option></select></label><select className="filter-field" value={accountFilter} onChange={e=>setAccountFilter(e.target.value)}><option value="all">كل الحسابات</option>{accounts.map(a=><option value={a.id} key={a.id}>{a.name}</option>)}</select><input className="filter-field" aria-label="من تاريخ" type="date" value={fromDate} onChange={e=>setFromDate(e.target.value)}/><input className="filter-field" aria-label="إلى تاريخ" type="date" value={toDate} onChange={e=>setToDate(e.target.value)}/><input className="search-input" placeholder="ابحث بالوصف أو الطرف..." value={search} onChange={e=>setSearch(e.target.value)}/><button className="button ghost small" onClick={()=>launch('transfer')}><ArrowLeftRight/>تحويل بين حسابين</button></div>}
      {page === 'obligations' && <div className="filters"><label className="filter-field"><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">كل الحالات</option><option value="due">مستحق</option><option value="paid">مدفوع</option></select></label><div className="notice" style={{margin:0}}>التذكيرات تظهر داخل التطبيق؛ لا يخصم التطبيق أي مبلغ تلقائياً.</div></div>}
      {(page === 'accounts' || page === 'shops' || page === 'debts') && <div className="filters"><input className="search-input" placeholder="بحث..." value={search} onChange={e=>setSearch(e.target.value)}/></div>}
      {columnsTable(rows, mode)}
    </>;
  }
  function shopStatement() {
    const shop = byId(filter);
    const rows = records.filter(r => r.shopId === filter && (!fromDate || (r.date||'')>=fromDate) && (!toDate || (r.date||'')<=toDate) && (statementType==='all'||r.kind===statementType)).sort((a,b)=>(a.date||'').localeCompare(b.date||''));
    return <>
      {pageHeader(`كشف حساب · ${shop?.name || 'المحل'}`, 'حركة الفواتير والدفعات والتسويات بالتسلسل الزمني.', <div style={{display:'flex',gap:8,flexWrap:'wrap'}}><button className="button ghost" onClick={printPage}><Printer/>طباعة / PDF</button><button className="button ghost small" onClick={()=>launch('shopCashPurchase',{shopId:filter})}>شراء نقدي</button><button className="button ghost small" onClick={()=>launch('shopPayment',{shopId:filter})}>دفعة</button><button className="button ghost small" onClick={()=>launch('shopReturn',{shopId:filter})}>مرتجع / خصم</button><button className="button ghost small" onClick={()=>launch('shopAdjustment',{shopId:filter})}>تسوية</button><button className="button" onClick={()=>launch('shopCreditPurchase',{shopId:filter})}><Plus/>فاتورة آجل</button></div>)}
      <div className="summary-grid"><div className="summary-card primary-card"><div className="metric-label">الرصيد الحالي · {shop?.balanceDirection || (shopBalance(shop||{}) >= 0 ? 'مستحق للمحل' : 'رصيد دائن لي')}</div><div className="metric-value">{money(shopBalance(shop||{}),shop?.currency)}</div></div><div className="summary-card"><div className="metric-label">رقم الاتصال</div><div className="metric-value" style={{fontSize:18}}>{shop?.phone || '—'}</div></div></div>
      <div className="filters"><select className="filter-field" value={statementType} onChange={e=>setStatementType(e.target.value)}><option value="all">كل أنواع الحركة</option><option value="shopCreditPurchase">شراء آجل</option><option value="shopCashPurchase">شراء نقدي</option><option value="shopPayment">دفعة</option><option value="shopReturn">مرتجع</option><option value="shopAdjustment">تسوية</option></select><input className="filter-field" type="date" aria-label="من تاريخ" value={fromDate} onChange={e=>setFromDate(e.target.value)}/><input className="filter-field" type="date" aria-label="إلى تاريخ" value={toDate} onChange={e=>setToDate(e.target.value)}/><button className="button ghost small" onClick={()=>{setFromDate('');setToDate('');setStatementType('all');}}><X/>مسح التصفية</button><button className="button ghost small" onClick={printPage}><Printer/>طباعة كشف الحساب</button></div>
      {rows.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>التاريخ</th><th>رقم الفاتورة</th><th>البيان</th><th>النوع</th><th>المبلغ</th><th>السبب</th><th>إجراءات</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{r.date}</td><td>{r.invoice || '—'}</td><td>{r.description || r.name || '—'}</td><td>{r.kind === 'shopCreditPurchase' ? 'شراء آجل' : r.kind === 'shopCashPurchase' ? 'شراء نقدي' : r.kind === 'shopPayment' ? 'دفعة' : r.kind === 'shopReturn' ? 'مرتجع' : 'تسوية'}</td><td>{money(r.amount||0,shop?.currency)}</td><td>{r.reason || '—'}</td><td><div className="row-actions"><button className="row-action" onClick={()=>launch(r.kind,r)} title="تعديل"><Pencil/></button><button className="row-action" onClick={()=>deleteItem(r)} title="حذف"><Trash2/></button></div></td></tr>)}</tbody></table></div> : empty('لا توجد حركة لهذا المحل','أضف فاتورة أو دفعة لتكوين كشف الحساب.','فاتورة جديدة',()=>launch('shopCreditPurchase',{shopId:filter}))}
    </>;
  }
  function reports() {
    const transactionsForReport = records.filter(r => r.kind === 'transaction');
    const filtered = transactionsForReport.filter(r => {
      if (reportPeriod === 'month') return (r.date||'').startsWith(monthStart);
      if (reportPeriod === 'year') return (r.date||'').startsWith(today().slice(0,4));
      return true;
    }).filter(r=>(byId(r.accountId)?.currency===reportCurrency)&&(filter==='all'||r.accountId===filter)&&(!fromDate||(r.date||'')>=fromDate)&&(!toDate||(r.date||'')<=toDate)&&(!search||JSON.stringify([r.category,r.counterparty,r.description]).toLowerCase().includes(search.toLowerCase())));
    const incomes = filtered.filter(r=>r.type==='income').reduce((s,r)=>s+(r.amount||0),0);
    const expenses = filtered.filter(r=>r.type==='expense').reduce((s,r)=>s+(r.amount||0),0);
    const monthly = Array.from({length:6},(_,i)=>{
      const d=new Date(); d.setMonth(d.getMonth()-(5-i)); const prefix=d.toISOString().slice(0,7);
      const items=transactionsForReport.filter(r=>(r.date||'').startsWith(prefix)&&byId(r.accountId)?.currency===reportCurrency&&(filter==='all'||r.accountId===filter)&&(!fromDate||(r.date||'')>=fromDate)&&(!toDate||(r.date||'')<=toDate)&&(!search||JSON.stringify([r.category,r.counterparty,r.description]).toLowerCase().includes(search.toLowerCase())));
      return {label:new Intl.DateTimeFormat('ar',{month:'short'}).format(d),income:items.filter(r=>r.type==='income').reduce((s,r)=>s+(r.amount||0),0),expense:items.filter(r=>r.type==='expense').reduce((s,r)=>s+(r.amount||0),0)};
    });
    const max = Math.max(1,...monthly.flatMap(m=>[m.income,m.expense]));
    return <>{pageHeader('التقارير', 'قراءة واضحة لأرقامك المسجلة فقط. لا بيانات افتراضية.', <div style={{display:'flex',gap:8}}><button className="button ghost" onClick={printPage}><Printer/>طباعة / PDF</button><button className="button" onClick={()=>exportCsv(filtered)}><FileDown/>تصدير CSV</button></div>)}
      <div className="filters"><label className="filter-field"><select value={reportPeriod} onChange={e=>setReportPeriod(e.target.value)}><option value="month">هذا الشهر</option><option value="year">هذه السنة</option><option value="all">كل المدة</option></select></label><select className="filter-field" value={reportCurrency} onChange={e=>setReportCurrency(e.target.value)}>{currencies.map(c=><option key={c} value={c}>{c}</option>)}</select><select className="filter-field" value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">كل الحسابات</option>{accounts.filter(a=>a.currency===reportCurrency).map(a=><option key={a.id} value={a.id}>{a.name}</option>)}</select><input className="filter-field" type="date" aria-label="من تاريخ" value={fromDate} onChange={e=>setFromDate(e.target.value)}/><input className="filter-field" type="date" aria-label="إلى تاريخ" value={toDate} onChange={e=>setToDate(e.target.value)}/><input className="search-input" placeholder="تصنيف أو طرف أو وصف..." value={search} onChange={e=>setSearch(e.target.value)}/></div>
      <div className="summary-grid"><div className="summary-card"><div className="metric-label">إجمالي الدخل</div><div className="metric-value positive">{money(incomes,reportCurrency)}</div></div><div className="summary-card"><div className="metric-label">إجمالي المصروف</div><div className="metric-value negative">{money(expenses,reportCurrency)}</div></div><div className="summary-card"><div className="metric-label">الصافي</div><div className="metric-value">{money(incomes-expenses,reportCurrency)}</div></div></div>
      <section className="panel"><div className="panel-head"><div><h3>الدخل والمصروف · آخر ستة أشهر</h3><p>الرسم يعرض المجاميع الفعلية من سجلاتك فقط</p></div></div>{filtered.length ? <div className="chart-wrap"><div className="report-chart">{monthly.map((m,i)=><div className="bar-group" key={`${m.label}-${i}`}><div className="bar" style={{height:`${m.income/max*100}%`}} title={`دخل: ${money(m.income)}`}/><div className="bar expense" style={{height:`${m.expense/max*100}%`}} title={`مصروف: ${money(m.expense)}`}/><span className="bar-label">{m.label}</span></div>)}</div><div style={{display:'flex',gap:16,fontSize:11,marginTop:32}}><span><i className="badge good"/> دخل</span><span><i className="badge warn"/> مصروف</span></div></div>:empty('لا توجد بيانات للرسم','سجّل دخلاً أو مصروفاً لعرض تقرير حقيقي.')}</section>
      {columnsTable(filtered,'transactions')}
    </>;
  }
  function settingsPage() {
    return <>{pageHeader('الإعدادات', 'تفضيلاتك تبقى محفوظة محلياً على هذا الجهاز.')}
      <div className="settings-grid">
        <section className="setting-card"><h3>التفضيلات المالية</h3><p>اختر العملة وطريقة عرض المبالغ والتواريخ.</p><div className="field"><label>العملة الافتراضية</label><select value={prefs.currency} onChange={e=>updatePrefs({currency:e.target.value})}>{currencies.map(c=><option key={c}>{c}</option>)}</select></div><div className="field" style={{marginTop:12}}><label>المنازل العشرية</label><select value={prefs.decimals} onChange={e=>updatePrefs({decimals:Number(e.target.value)})}><option value={0}>بدون كسور</option><option value={2}>منزلتان عشريتان</option></select></div><div className="field" style={{marginTop:12}}><label>تنسيق التاريخ</label><select value={prefs.dateFormat} onChange={e=>updatePrefs({dateFormat:e.target.value})}><option value="ymd">سنة - شهر - يوم</option><option value="dmy">يوم - شهر - سنة</option></select></div></section>
        <section className="setting-card"><h3>المظهر والخصوصية</h3><p>تحكم بما يظهر على الشاشة عند استخدامك للتطبيق.</p><div className="switch-line"><span>الوضع الداكن</span><button className={`switch ${prefs.theme==='dark'?'on':''}`} aria-label="الوضع الداكن" onClick={()=>updatePrefs({theme:prefs.theme==='dark'?'light':'dark'})}/></div><div className="switch-line"><span>إخفاء الأرصدة</span><button className={`switch ${prefs.hidden?'on':''}`} aria-label="إخفاء الأرصدة" onClick={()=>updatePrefs({hidden:!prefs.hidden})}/></div></section>
        <section className="setting-card"><h3>قفل محلي برقم PIN</h3><p>القفل يحدّ الوصول العادي للتطبيق على هذا الجهاز، لكنه ليس تشفيراً ولا يحمي ملفات الجهاز أو قاعدة البيانات من مستخدم متقدم.</p><div className="field"><label>رقم PIN اختياري (4–8 أرقام)</label><input inputMode="numeric" maxLength={8} value={prefs.pin} onChange={e=>updatePrefs({pin:e.target.value.replace(/\D/g,'').slice(0,8)})} placeholder="اتركه فارغاً للتعطيل"/></div><div className="notice"><ShieldCheck size={14}/> لا تستخدم PIN بديلاً عن حماية الجهاز. بيانات الحسابات محفوظة محلياً وليست مشفرة.</div></section>
        <section className="setting-card"><h3>بياناتك والنسخ الاحتياطي</h3><p>كل السجلات المالية على هذا الجهاز. احتفظ بنسخة احتياطية في مكان آمن.</p><div style={{display:'flex',gap:9,flexWrap:'wrap'}}><button className="button small" onClick={exportBackup}><Download/>تصدير JSON</button><label className="button ghost small"><Upload/>استيراد JSON<input type="file" accept=".json,application/json" hidden onChange={e=>importBackup(e.target.files?.[0])}/></label></div><div className="notice">استيراد النسخة يدمج السجلات حسب المعرّف ولا يستبدل بياناتك الحالية.</div></section>
        <section className="setting-card"><h3>تثبيت حساباتي</h3><p>استخدم التطبيق كتجربة قريبة من التطبيق الأصلي على جهازك.</p><button className="button ghost small" disabled={!installPrompt} onClick={async()=>{if(installPrompt){await installPrompt.prompt();setInstallPrompt(null);}}}><Download/>تثبيت التطبيق</button>{!installPrompt&&<small style={{display:'block',marginTop:9,color:'var(--muted-foreground)'}}>إذا لم يظهر خيار التثبيت، افتح قائمة المتصفح واختر «إضافة إلى الشاشة الرئيسية».</small>}</section>
      </div></>;
  }
  function calculator() {
    const keys=['C','%','⌫','÷','7','8','9','×','4','5','6','−','1','2','3','+','±','0','.','='];
    return <>{pageHeader('الآلة الحاسبة','حساب مستقل لا يغيّر أرصدتك ولا ينشئ سجلاً.')}<section className="panel calc"><div className="calc-display"><small>{calcExpr.replaceAll('*','×').replaceAll('/','÷')}</small><b>{calc}</b></div><div className="calc-grid">{keys.map(k=><button key={k} className={`calc-key ${'+−×÷%'.includes(k)?'operator':''} ${k==='='?'equals':''}`} onClick={()=>k==='−'?calcKey('-'):k==='±'?setCalc(v=>String(-Number(v))):calcKey(k)}>{k}</button>)}</div></section></>;
  }
  function renderPage() {
    if (page === 'home') return dashboard();
    if (page === 'accounts' || page === 'transactions' || page === 'debts' || page === 'shops' || page === 'obligations') return listPage();
    if (page === 'debtStatement') return debtStatement();
    if (page === 'shopStatement') return shopStatement();
    if (page === 'reports') return reports();
    if (page === 'settings') return settingsPage();
    if (page === 'calculator') return calculator();
    return dashboard();
  }
  function modalTitle(kind: string) {
    const names: Record<string,string> = { account:'حساب مالي', transaction:'حركة مالية', transfer:'تحويل بين حسابين', debt:'تسجيل دين', debtPayment:'تسجيل سداد', shop:'حساب محل', shopCreditPurchase:'فاتورة شراء آجل', shopCashPurchase:'شراء نقدي', shopPayment:'دفعة للمحل', shopReturn:'مرتجع / خصم', shopAdjustment:'تسوية رصيد', obligation:'التزام مالي' };
    return names[kind] || 'إضافة سجل';
  }
  function ModalForm() {
    const { kind, item } = modal!;
    const form = modalForm;
    const error = modalError;
    const setError = setModalError;
    const set = (key: string, value: any) => setModalForm(f => ({ ...f, [key]: value }));
    const labels: Record<string,string> = { income:'دخل', expense:'مصروف', owedToMe:'مستحق لي', iOwe:'مستحق عليّ', due:'مستحق', paid:'مدفوع', increase:'زيادة', decrease:'نقص' };
    const field = (label: string, key: string, type='text', options?: string[], full=false) => <div className={`field ${full?'full':''}`} key={key}><label>{label}</label>{options ? <select value={form[key] ?? options[0]} onChange={e=>set(key,e.target.value)}>{options.map(o=><option key={o} value={o}>{labels[o] || o}</option>)}</select> : <input type={type} step={type==='number'?'any':undefined} value={form[key] ?? ''} onChange={e=>set(key,e.target.value)} required={['name','amount','date','person','dueDate'].includes(key)} />}</div>;
    const amountField = () => field('المبلغ', 'amount','number');
    async function submit(e: FormEvent) {
      e.preventDefault(); if (busy) return;
      try {
        const amount = moneyIn(String(form.amount ?? '0'));
        if (['transaction','transfer','debtPayment','shopCreditPurchase','shopCashPurchase','shopPayment','shopReturn','shopAdjustment','obligation'].includes(kind) && amount <= 0) throw new Error('يجب أن يكون المبلغ أكبر من صفر');
        const record: Item = { ...form, id: item?.id || id(), kind, amount, updatedAt: new Date().toISOString(), createdAt: item?.createdAt || new Date().toISOString() };
        if (kind === 'account' || kind === 'shop') { record.opening = moneyIn(String(form.opening || '0')); delete record.amount; }
        if (kind === 'transaction') { if(!accounts.some(a=>a.id===form.accountId)) throw new Error('اختر حساباً صالحاً لهذه الحركة'); record.amount = amount; }
        if (kind === 'debt') {
          const alreadyPaid=records.filter(p=>p.kind==='debtPayment'&&p.debtId===item?.id).reduce((s,p)=>s+(p.amount||0),0);
          if(amount<alreadyPaid) throw new Error('لا يمكن أن يكون أصل الدين أقل من الدفعات المسجلة');
          record.amount = amount; record.currency = form.currency || prefs.currency;
        }
        if (kind === 'transfer') { record.type='transfer'; record.fromId=form.fromId; record.toId=form.toId; if(record.fromId===record.toId) throw new Error('اختر حسابين مختلفين للتحويل'); const from=byId(record.fromId),to=byId(record.toId); if(!from||!to) throw new Error('اختر حسابين صالحين'); if(from.currency!==to.currency) throw new Error('يجب أن تكون عملة الحسابين متطابقة للتحويل المباشر'); }
        if (kind === 'debtPayment') {
          record.debtId=item?.debtId || form.debtId; record.direction=item?.direction || byId(record.debtId)?.direction; record.accountId=form.accountId; record.date=form.date; record.description=form.description || 'سداد دين';
          const parentDebt=byId(record.debtId);
          if(!parentDebt) throw new Error('اختر ديناً صالحاً');
          if(!accounts.some(a=>a.id===form.accountId)) throw new Error('اختر الحساب الذي استلمت أو دفعت منه');
          const otherPayments=records.filter(p=>p.kind==='debtPayment'&&p.debtId===record.debtId&&p.id!==item?.id).reduce((s,p)=>s+(p.amount||0),0);
          if(amount>(parentDebt.amount||0)-otherPayments) throw new Error('مبلغ السداد أكبر من المتبقي على الدين');
        }
        if (kind.startsWith('shop') && kind !== 'shop') {
          record.shopId=item?.shopId || form.shopId;
          if (!record.shopId) throw new Error('اختر المحل');
          if (kind === 'shopCreditPurchase' || kind === 'shopCashPurchase') record.invoice = item?.invoice || `F-${record.id.slice(0,8).toUpperCase()}`;
          if (kind === 'shopCashPurchase' || kind === 'shopPayment') { record.accountId=form.accountId; if(!accounts.some(a=>a.id===form.accountId)) throw new Error('اختر حساباً صالحاً للحركة النقدية'); }
          if(kind==='shopReturn'&&form.accountId){record.accountId=form.accountId;if(!accounts.some(a=>a.id===form.accountId))throw new Error('اختر حساباً صالحاً لاسترداد المبلغ');}
          if((kind==='shopReturn'||kind==='shopAdjustment')&&!String(form.reason||'').trim()) throw new Error('اكتب سبب المرتجع أو التسوية');
          record.description=form.description || modalTitle(kind);
        }
        if (kind === 'obligation') { record.status = form.status || item?.status || 'due'; record.nature = form.nature || item?.nature || 'expense'; }
        await persist(record); setModal(null);
      } catch(err) { setError(err instanceof Error ? err.message : 'راجع البيانات المدخلة'); }
    }
    const selectAccount = (label='الحساب') => <div className="field" key="account"><label>{label}</label><select value={form.accountId || ''} onChange={e=>set('accountId',e.target.value)}><option value="">اختر الحساب</option>{accounts.map(a=><option key={a.id} value={a.id}>{a.name} · {a.currency}</option>)}</select></div>;
    const accountOpen = kind === 'account';
    return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(null);}}><form className="modal" onSubmit={submit}><div className="modal-head"><div><h3>{item ? 'تعديل' : 'إضافة'} {modalTitle(kind)}</h3><p>سيُحفظ السجل محلياً على هذا الجهاز فقط.</p></div><button type="button" className="modal-close" onClick={()=>setModal(null)}><X size={17}/></button></div>
      {kind === 'account' && <div className="form-grid">{field('اسم الحساب','name')}{field('نوع الحساب','accountType','text',['نقدي','بنك','محفظة إلكترونية','أخرى'])}{field('الرصيد الافتتاحي','opening','number')}{field('العملة','currency','text',currencies)}{error&&<div className="field full notice">{error}</div>}</div>}
      {kind === 'transaction' && <div className="form-grid">{field('نوع الحركة','type','text',['expense','income'])}{amountField()}{field('التصنيف','category','text',form.type==='income'?['راتب','عمل حر','إيجار مستلم','هدية','أخرى']:['طعام','منزل','تنقل','صحة','تسوق','فواتير','أخرى'])}{selectAccount()}{field('التاريخ','date','date')}{field('الطرف المقابل','counterparty')}{field('الوصف','description','text',undefined,true)}{field('ملاحظات','notes','text',undefined,true)}</div>}
      {kind === 'transfer' && <div className="form-grid"><div className="field"><label>من حساب</label><select value={form.fromId||''} onChange={e=>set('fromId',e.target.value)}><option value="">اختر الحساب</option>{accounts.map(a=><option key={a.id} value={a.id}>{a.name} · {a.currency}</option>)}</select></div><div className="field"><label>إلى حساب</label><select value={form.toId||''} onChange={e=>set('toId',e.target.value)}><option value="">اختر الحساب</option>{accounts.map(a=><option key={a.id} value={a.id}>{a.name} · {a.currency}</option>)}</select></div>{amountField()}{field('التاريخ','date','date')}{field('الوصف','description','text',undefined,true)}<small className="field full">التحويل لا يدخل ضمن الدخل أو المصروف. {accounts.length===0?'أضف حسابين أولاً.':''}</small></div>}
      {kind === 'debt' && <div className="form-grid">{field('اسم الشخص','person')}{field('الاتجاه','direction','text',['owedToMe','iOwe'])}{amountField()}{field('العملة','currency','text',currencies)}{field('التاريخ','date','date')}{field('وصف الدين','note','text',undefined,true)}{field('موعد متوقع للسداد','dueDate','date')}</div>}
      {kind === 'debtPayment' && <div className="form-grid">{!item?.debtId&&<div className="field full"><label>الدين</label><select value={form.debtId||''} onChange={e=>{const d=byId(e.target.value);set('debtId',e.target.value);set('direction',d?.direction);set('currency',d?.currency);}}><option value="">اختر الشخص / الدين</option>{debts.map(d=><option value={d.id} key={d.id}>{d.person} · {d.direction==='owedToMe'?'مستحق لي':'مستحق عليّ'} · {money((d.amount||0)-records.filter(p=>p.kind==='debtPayment'&&p.debtId===d.id).reduce((s,p)=>s+(p.amount||0),0),d.currency)}</option>)}</select></div>}{amountField()}{selectAccount()}{field('التاريخ','date','date')}{field('ملاحظات','description','text',undefined,true)}<div className="field full notice">يسجل السداد أثراً نقدياً على الحساب المختار، ولا يتجاوز الرصيد المتبقي في كشف الدين.</div></div>}
      {kind === 'shop' && <div className="form-grid">{field('اسم المحل','name')}{field('اسم جهة الاتصال','contact')}{field('رقم الهاتف','phone','tel')}{field('البريد أو العنوان','address')}{field('الرصيد الافتتاحي المستحق للمحل','opening','number')}{field('العملة','currency','text',currencies)}</div>}
      {['shopCreditPurchase','shopCashPurchase','shopPayment','shopReturn','shopAdjustment'].includes(kind) && <div className="form-grid">{!item?.shopId&&<div className="field"><label>المحل</label><select value={form.shopId||''} onChange={e=>set('shopId',e.target.value)}><option value="">اختر محلاً</option>{shops.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></div>}{field('المبلغ','amount','number')}{field('التاريخ','date','date')}{(kind==='shopCashPurchase'||kind==='shopPayment')&&selectAccount(kind==='shopPayment'?'الحساب الذي دُفع منه':'الحساب النقدي')}{kind==='shopReturn'&&<div className="field"><label>حساب استرداد نقدي (اختياري)</label><select value={form.accountId||''} onChange={e=>set('accountId',e.target.value)}><option value="">تسوية رصيد المحل فقط</option>{accounts.map(a=><option key={a.id} value={a.id}>{a.name}</option>)}</select></div>}{kind==='shopAdjustment'&&field('اتجاه التسوية','direction','text',['increase','decrease'])}{field(kind==='shopAdjustment'||kind==='shopReturn'?'سبب التعديل / المرتجع':'الوصف','reason','text',undefined,true)}{field('الوصف','description','text',undefined,true)}{kind==='shopCreditPurchase'&&<div className="notice field full">سيُنشأ رقم فاتورة تلقائي. يمكن طباعة كشف الحساب لاحقاً.</div>}</div>}
      {kind === 'obligation' && <div className="form-grid">{field('اسم الالتزام أو الدخل المتكرر','name')}{field('النوع','nature','text',['expense','income'])}{amountField()}{field('العملة','currency','text',currencies)}{field('موعد الاستحقاق','dueDate','date')}{field('التكرار','recurrence','text',['مرة واحدة','أسبوعي','شهري','سنوي'])}{field('الحالة','status','text',['due','paid'])}{field('ملاحظات','notes','text',undefined,true)}<div className="notice field full">للتذكير فقط: سجّل الراتب أو الدخل عند استلامه. لا يتم إنشاء دخل أو خصم مصروف تلقائياً.</div></div>}
      {error && <div className="notice">{error}</div>}
      <div className="modal-actions"><button className="button" type="submit" disabled={busy}>{busy?'جارٍ الحفظ…':item?'حفظ التغييرات':'حفظ السجل'}</button><button className="button ghost" type="button" onClick={()=>setModal(null)}>إلغاء</button></div>
    </form></div>;
  }
  return <div className="app-shell" dir="rtl">
    {splash&&<div className="splash"><div className="splash-inner"><div className="splash-mark">ح</div><h1>حساباتي</h1><p>Ali AlKHAlqy</p></div></div>}
    {pinGate&&prefs.pin&&<div className="modal-backdrop" style={{zIndex:110}}><form className="modal" style={{maxWidth:370,textAlign:'center'}} onSubmit={e=>{e.preventDefault();if(pinEntry===prefs.pin){setPinGate(false);setPinEntry('');}else showToast('رقم PIN غير صحيح');}}><div className="empty-illustration"><LockKeyhole/></div><h3>أهلاً بعودتك</h3><p>أدخل PIN المحلي للمتابعة</p><input className="search-input" style={{width:'100%',textAlign:'center',margin:'10px 0'}} type="password" inputMode="numeric" value={pinEntry} onChange={e=>setPinEntry(e.target.value)} autoFocus/><button className="button" type="submit">فتح حساباتي</button></form></div>}
    <aside className="sidebar"><div className="brand"><div className="brand-mark">ح</div><div><strong>حساباتي</strong><small>Ali AlKHAlqy</small></div></div><div className="nav-caption">إدارة أموالك</div><nav className="nav-list"><NavButtons/></nav><div className="sidebar-foot">مساحة شخصية · محفوظة على هذا الجهاز<b>Ali AlKHAlqy</b></div></aside>
    <main className="main"><header className="topbar"><div className="welcome"><small>{new Intl.DateTimeFormat('ar-YE',{weekday:'long',day:'numeric',month:'long'}).format(new Date())}</small><h1>{page==='home'?'مرحباً بك في مساحتك المالية':titles[page] || 'كشف حساب'}</h1></div><div className="top-actions"><button className="icon-btn" title="إخفاء الأرصدة" onClick={()=>updatePrefs({hidden:!prefs.hidden})}>{prefs.hidden?<EyeOff size={17}/>:<Eye size={17}/>}</button><button className="icon-btn" title="تبديل المظهر" onClick={()=>updatePrefs({theme:prefs.theme==='dark'?'light':'dark'})}>{prefs.theme==='dark'?<Sun size={17}/>:<Moon size={17}/>}</button><button className="profile-btn" onClick={()=>changePage('settings')}><span className="profile-dot">ع</span><span>حساباتي</span></button></div></header>
      {renderPage()}
      <div style={{textAlign:'center',fontSize:10,color:'hsl(var(--muted-foreground))',padding:'28px 0 0'}}>بياناتك تبقى على هذا الجهاز · لا اتصال بنكي · Ali AlKHAlqy</div>
    </main>
    <nav className="mobile-nav"><NavButtons/></nav>
    {modal&&ModalForm()}{toast&&<div className="toast" role="status">{toast}</div>}
  </div>;
}
export default App;
