import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.alialkhalqy.hesabati',
  appName: 'حساباتي',
  webDir: 'dist/public',
  android: {
    backgroundColor: '#f8fafc',
  },
};

export default config;
